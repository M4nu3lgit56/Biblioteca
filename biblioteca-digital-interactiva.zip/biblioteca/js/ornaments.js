// A small set of hand-authored SVG ornaments so every book looks
// individually crafted without needing external image assets.
// Deterministic "random" pick based on the book id, so a given
// book always gets the same ornament across reloads.

function hashString(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

// Small geometric/foil-stamp style emblems for the spine (gold line art).
const flourishes = [
  `<svg viewBox="0 0 40 40"><path d="M20 4 L20 36 M8 20 L32 20" stroke="currentColor" stroke-width="1" opacity=".7"/><circle cx="20" cy="20" r="4.5" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
  `<svg viewBox="0 0 40 40"><path d="M20 6 L26 20 L20 34 L14 20 Z" fill="none" stroke="currentColor" stroke-width="1"/><circle cx="20" cy="20" r="1.6" fill="currentColor"/></svg>`,
  `<svg viewBox="0 0 40 40"><path d="M10 20 C10 12 16 8 20 8 C24 8 30 12 30 20 C30 28 24 32 20 32 C16 32 10 28 10 20 Z" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
  `<svg viewBox="0 0 40 40"><path d="M20 8 L20 32 M14 12 L26 12 M14 28 L26 28" stroke="currentColor" stroke-width="1"/></svg>`,
  `<svg viewBox="0 0 40 40"><path d="M12 12 L28 28 M28 12 L12 28" stroke="currentColor" stroke-width="1" opacity=".6"/><circle cx="20" cy="20" r="6" fill="none" stroke="currentColor" stroke-width="1"/></svg>`,
  `<svg viewBox="0 0 40 40"><path d="M20 6 Q30 20 20 34 Q10 20 20 6 Z" fill="none" stroke="currentColor" stroke-width="1"/><path d="M20 12 L20 28" stroke="currentColor" stroke-width="1"/></svg>`,
];

// Quiet decorative silhouettes placed occasionally between shelves.
const props = {
  plant: `<svg viewBox="0 0 60 90"><rect x="18" y="62" width="24" height="24" rx="2" fill="currentColor" opacity=".9"/>
    <path d="M30 62 C30 40 14 34 10 18 C24 22 30 34 30 46 C30 34 36 20 50 16 C48 32 32 40 30 62 Z" fill="currentColor" opacity=".85"/></svg>`,
  vase: `<svg viewBox="0 0 60 90"><path d="M24 20 Q30 10 36 20 L40 40 Q44 60 30 66 Q16 60 20 40 Z" fill="currentColor" opacity=".9"/>
    <path d="M30 20 L26 4 M30 20 L34 2 M30 20 L20 8 M30 20 L40 6" stroke="currentColor" stroke-width="1.4" opacity=".8"/></svg>`,
  lamp: `<svg viewBox="0 0 60 90"><path d="M16 22 L44 22 L36 46 L24 46 Z" fill="currentColor" opacity=".85"/>
    <rect x="27" y="46" width="6" height="26" fill="currentColor" opacity=".9"/>
    <rect x="16" y="72" width="28" height="6" rx="2" fill="currentColor" opacity=".9"/></svg>`,
};
const propKeys = Object.keys(props);

export function ornamentFor(id) {
  const h = hashString(id);
  return flourishes[h % flourishes.length];
}

export function propFor(index) {
  return props[propKeys[index % propKeys.length]];
}
