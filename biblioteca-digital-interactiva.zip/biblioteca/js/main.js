import { loadLibrary } from "./data.js";
import { initBook, openBook } from "./book.js";
import { getReadIds, markRead } from "./progress.js";
import { createVoxelLibrary } from "./voxel-scene.js";

const soundToggle = document.getElementById("sound-toggle");
const iconOn = soundToggle.querySelector(".icon-sound-on");
const iconOff = soundToggle.querySelector(".icon-sound-off");
const ambient = document.getElementById("audio-ambient");
const counterEl = document.getElementById("read-counter");
const panHint = document.getElementById("pan-hint");
const sceneContainer = document.getElementById("scene-container");
const sceneFallback = document.getElementById("scene-fallback");

const sounds = {
  pull: document.getElementById("audio-pull"),
  open: document.getElementById("audio-open"),
  page: document.getElementById("audio-page"),
  close: document.getElementById("audio-close"),
};

let musicOn = false;
soundToggle.addEventListener("click", () => {
  musicOn = !musicOn;
  soundToggle.setAttribute("aria-pressed", String(musicOn));
  iconOn.hidden = musicOn;
  iconOff.hidden = !musicOn;
  if (musicOn) {
    ambient.volume = 0.35;
    ambient.play().catch(() => {});
  } else {
    ambient.pause();
  }
});

function updateCounterText(readCount, total) {
  counterEl.textContent = `${readCount} de ${total} libros leídos`;
}

async function init() {
  let data;
  try {
    data = await loadLibrary();
  } catch (err) {
    sceneFallback.hidden = false;
    sceneFallback.textContent = `No se pudo cargar la biblioteca (${err.message}). Revisa que books/books.json exista.`;
    return;
  }

  const readIds = getReadIds();
  const total = data.libros.length;
  updateCounterText([...readIds].filter((id) => data.libros.some((l) => l.id === id)).length, total);

  let secretRevealed = data.libroSecreto
    ? data.libros.every((l) => readIds.has(l.id))
    : false;

  initBook(sounds, (libro) => {
    const isSecret = data.libroSecreto && libro.id === data.libroSecreto.id;
    if (isSecret) return; // el libro secreto no cuenta para el contador

    const wasNew = markRead(libro.id);
    if (!wasNew) return;
    readIds.add(libro.id);

    const readCount = data.libros.filter((l) => readIds.has(l.id)).length;
    updateCounterText(readCount, total);
    if (scene) scene.setReadIds(readIds);

    if (!secretRevealed && data.libroSecreto && readCount === total) {
      secretRevealed = true;
      if (scene) scene.addSecretBook(data.libroSecreto);
    }
  });

  let scene;
  try {
    scene = createVoxelLibrary({
      container: sceneContainer,
      libros: data.libros,
      readIds,
      onSelectBook: (libro) => openBook(libro),
    });
  } catch (err) {
    console.error("Error al iniciar la biblioteca 3D:", err);
    sceneFallback.hidden = false;
    sceneFallback.textContent =
      "No se pudo iniciar la biblioteca en 3D. Detalle técnico: " + (err && err.message ? err.message : String(err));
    return;
  }

  if (!scene) {
    sceneFallback.hidden = false;
    return;
  }

  if (secretRevealed && data.libroSecreto) {
    scene.addSecretBook(data.libroSecreto);
  }

  // A brief one-time hint that the scene can be dragged to explore it.
  window.setTimeout(() => panHint.classList.add("is-visible"), 900);
  window.setTimeout(() => panHint.classList.remove("is-visible"), 5200);
}

init();
