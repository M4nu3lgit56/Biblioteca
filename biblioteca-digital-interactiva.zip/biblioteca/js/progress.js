const STORAGE_KEY = "biblioteca-para-ti:progreso";

function readState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return parsed && Array.isArray(parsed.leidos) ? parsed : { leidos: [] };
  } catch (_) {
    return { leidos: [] };
  }
}

function writeState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (_) {
    // localStorage puede fallar en modo privado; la app sigue funcionando,
    // solo no recordará el progreso entre visitas.
  }
}

export function getReadIds() {
  return new Set(readState().leidos);
}

export function isRead(id) {
  return getReadIds().has(id);
}

// Devuelve true solo si el libro se marca como leído por primera vez,
// para que quien llame sepa si debe sumar al contador o ya estaba contado.
export function markRead(id) {
  const state = readState();
  if (state.leidos.includes(id)) return false;
  state.leidos.push(id);
  writeState(state);
  return true;
}

export function resetProgress() {
  writeState({ leidos: [] });
}
