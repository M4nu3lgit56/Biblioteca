// Loads the library content from an external JSON file so that
// no content has to live inside the HTML/JS.
export async function loadLibrary(path = "books/books.json") {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`No se pudo cargar ${path}`);
  return res.json();
}

// Groups books into shelves of a maximum size, so the shelf
// layout scales automatically as more books are added.
export function groupIntoShelves(libros, perShelf = 5) {
  const shelves = [];
  for (let i = 0; i < libros.length; i += perShelf) {
    shelves.push(libros.slice(i, i + perShelf));
  }
  return shelves;
}
