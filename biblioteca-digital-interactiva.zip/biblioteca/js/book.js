import { ornamentFor } from "./ornaments.js";

let sounds = {};
let currentBook = null;
let flip = null; // StPageFlip instance
let onFinishBook = null;
let finishedThisOpening = false;

const stage = document.getElementById("stage");
const bookCover = document.getElementById("book-cover");
const coverTitle = bookCover.querySelector(".cover-title");
const coverAuthor = bookCover.querySelector(".cover-author");
const bookPages = document.getElementById("book-pages");
const flipMount = document.getElementById("flip-mount");
const swipeHint = document.getElementById("swipe-hint");
const prevBtn = document.getElementById("prev-page");
const nextBtn = document.getElementById("next-page");
const counterCurrent = document.getElementById("page-counter-current");
const counterTotal = document.getElementById("page-counter-total");
const closeBtn = document.getElementById("close-book");

export function initBook(audioElements, onFinish) {
  sounds = audioElements;
  onFinishBook = onFinish || null;
  prevBtn.addEventListener("click", () => flip && flip.flipPrev());
  nextBtn.addEventListener("click", () => flip && flip.flipNext());
  closeBtn.addEventListener("click", closeBook);

  document.addEventListener("keydown", (e) => {
    if (!stage.classList.contains("is-open") || !flip) return;
    if (e.key === "ArrowRight") flip.flipNext();
    if (e.key === "ArrowLeft") flip.flipPrev();
    if (e.key === "Escape") closeBook();
  });

  // Keep the flipbook nicely sized as the viewport changes.
  window.addEventListener("resize", () => {
    if (flip) flip.updateFromHtml(document.querySelectorAll("#flip-mount .stpf-page"));
  });
}

function play(name) {
  const el = sounds[name];
  if (!el) return;
  try {
    el.currentTime = 0;
    el.play().catch(() => {});
  } catch (_) {}
}

function renderPageContent(pagina) {
  if (!pagina) return "";
  switch (pagina.tipo) {
    case "frase":
      return `<p class="quote">${pagina.contenido}</p>`;
    case "mensaje_final":
      return `
        <div class="page-cover-inner">
          <p class="final-message">${pagina.contenido}</p>
          <span class="final-signature">Para ti</span>
        </div>`;
    case "texto":
    default:
      return `
        ${pagina.titulo ? `<p class="eyebrow-small">${pagina.titulo}</p><h2>${pagina.titulo}</h2>` : ""}
        <p>${pagina.contenido || ""}</p>`;
  }
}

function buildPageElements(libro) {
  const nodes = [];

  // Front hard cover — title, author and the description you wrote,
  // so nothing entered in books.json goes unused.
  const cover = document.createElement("div");
  cover.className = "stpf-page stpf-cover";
  cover.dataset.density = "hard";
  cover.style.setProperty("--book-color", libro.color || "#6b4226");
  cover.innerHTML = `
    <div class="page-inner page-cover-inner">
      <p class="cover-title">${libro.titulo}</p>
      <p class="cover-author">${libro.autor}</p>
      ${libro.descripcion ? `<p class="cover-description">${libro.descripcion}</p>` : ""}
    </div>`;
  nodes.push(cover);

  // Content pages — skip the "presentacion" entry since the cover
  // above already covers title/author/description.
  const contentPages = libro.paginas.filter((p) => p.tipo !== "presentacion");
  contentPages.forEach((pagina) => {
    const page = document.createElement("div");
    page.className = "stpf-page";
    page.innerHTML = `<div class="page-inner">${renderPageContent(pagina)}</div>`;
    nodes.push(page);
  });

  // Back hard cover with the same spine ornament used on the shelf.
  const back = document.createElement("div");
  back.className = "stpf-page stpf-cover";
  back.dataset.density = "hard";
  back.style.setProperty("--book-color", libro.color || "#6b4226");
  back.innerHTML = `
    <div class="page-inner page-cover-inner">
      <span class="back-cover-emblem">${ornamentFor(libro.id)}</span>
    </div>`;
  nodes.push(back);

  return nodes;
}

function updateCounter() {
  if (!flip) return;
  counterCurrent.textContent = flip.getCurrentPageIndex() + 1;
  counterTotal.textContent = flip.getPageCount();
  prevBtn.disabled = flip.getCurrentPageIndex() === 0;
  nextBtn.disabled = flip.getCurrentPageIndex() === flip.getPageCount() - 1;
}

let hintTimer = null;
function showSwipeHint() {
  swipeHint.classList.add("is-visible");
  clearTimeout(hintTimer);
  hintTimer = window.setTimeout(hideSwipeHint, 2800);
}
function hideSwipeHint() {
  swipeHint.classList.remove("is-visible");
  clearTimeout(hintTimer);
}

function initFlipbook(libro) {
  // St.PageFlip's destroy() removes its parent element from the DOM,
  // so each book gets a fresh container appended into the stable mount.
  flipMount.innerHTML = "";
  const container = document.createElement("div");
  container.className = "flip-container";
  flipMount.appendChild(container);

  const pages = buildPageElements(libro);
  pages.forEach((p) => container.appendChild(p));

  flip = new St.PageFlip(container, {
    width: 320,
    height: 460,
    size: "stretch",
    minWidth: 260,
    maxWidth: 480,
    minHeight: 380,
    maxHeight: 640,
    showCover: true,
    maxShadowOpacity: 0.5,
    mobileScrollSupport: false,
    flippingTime: 700,
  });

  flip.loadFromHTML(container.querySelectorAll(".stpf-page"));
  flip.on("flip", () => {
    play("page");
    updateCounter();
    hideSwipeHint();
    if (
      !finishedThisOpening &&
      flip.getCurrentPageIndex() === flip.getPageCount() - 1
    ) {
      finishedThisOpening = true;
      if (onFinishBook) onFinishBook(libro);
    }
  });
  updateCounter();
}

export function openBook(libro) {
  if (bookPages && !bookPages.hidden) return; // already reading a book
  currentBook = libro;
  finishedThisOpening = false;
  hideSwipeHint();

  coverTitle.textContent = libro.titulo;
  coverAuthor.textContent = libro.autor;
  bookCover.style.setProperty("--book-color", libro.color || "#6b4226");
  bookCover.classList.remove("is-opening", "is-hidden");
  bookPages.classList.remove("is-visible");
  bookPages.hidden = true;

  document.body.style.overflow = "hidden";
  stage.classList.add("is-open");
  stage.setAttribute("aria-hidden", "false");

  play("pull");

  // Cinematic launch: the cover leaves the shelf and rotates into view.
  window.setTimeout(() => {
    play("open");
    bookCover.classList.add("is-opening");
  }, 550);

  // Once the launch settles, hand off to the real flipbook so the
  // person can drag pages with a finger and see them curl naturally.
  window.setTimeout(() => {
    bookCover.classList.add("is-hidden");
    bookPages.hidden = false;
    initFlipbook(libro);
    requestAnimationFrame(() => bookPages.classList.add("is-visible"));
    // A gentle automatic flip past the cover, matching "se abre" from the brief.
    window.setTimeout(() => {
      if (!flip) return;
      flip.flipNext();
      window.setTimeout(showSwipeHint, 750);
    }, 450);
  }, 550 + 1100);
}

export function closeBook() {
  if (!currentBook) return;
  play("close");
  hideSwipeHint();

  bookPages.classList.remove("is-visible");
  window.setTimeout(() => {
    bookPages.hidden = true;
    stage.classList.remove("is-open");
    stage.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
    bookCover.classList.remove("is-opening", "is-hidden");
    if (flip) {
      try { flip.destroy(); } catch (_) {}
      flip = null;
    }
    flipMount.innerHTML = "";
    currentBook = null;
  }, 350);
}
