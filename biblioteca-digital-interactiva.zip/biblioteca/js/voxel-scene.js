import * as THREE from "three";

const ROW_HEIGHT = 2.6;
const BOOK_HEIGHT = 1.7;
const BOOK_DEPTH = 0.9;
const BOOK_GAP = 0.12;
const SHELF_DEPTH = 1.3;
const SHELF_THICK = 0.18;
const PER_ROW = 4;

function hashCode(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

function makeSoftDotTexture(hex) {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext("2d");
  const grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, hex || "rgba(255,225,170,0.95)");
  grad.addColorStop(1, "rgba(255,225,170,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(canvas);
}

// Throws if WebGL / three.js can't initialize, instead of silently
// swallowing the error — the caller decides how to show it.
export function createVoxelLibrary({ container, libros, readIds, onSelectBook }) {
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });

  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#1c130c");
  scene.fog = new THREE.Fog("#1c130c", 12, 26);

  const camera = new THREE.PerspectiveCamera(38, Math.max(0.1, container.clientWidth / Math.max(1, container.clientHeight)), 0.1, 100);
  camera.position.set(0, 0, 9);
  camera.lookAt(0, 0, 0);

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(container.clientWidth, container.clientHeight);
  if ("outputColorSpace" in renderer) renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  container.appendChild(renderer.domElement);
  renderer.domElement.style.touchAction = "none";

  // ---- Warm lighting, no dynamic shadow maps (keeps mobile Safari smooth) ----
  scene.add(new THREE.HemisphereLight(0xfff1d6, 0x2a1c10, 0.95));
  const sun = new THREE.DirectionalLight(0xffd9a0, 0.85);
  sun.position.set(4, 6, 8);
  scene.add(sun);
  const lampLight = new THREE.PointLight(0xffb066, 1.0, 13, 2);
  scene.add(lampLight);

  const worldGroup = new THREE.Group();
  scene.add(worldGroup);

  // ---- Shared materials ----
  const woodMat = new THREE.MeshStandardMaterial({ color: 0x6b4226, roughness: 0.9 });
  const woodDarkMat = new THREE.MeshStandardMaterial({ color: 0x3d2718, roughness: 0.95 });
  const pageMat = new THREE.MeshStandardMaterial({ color: 0xf1e6c8, roughness: 0.8 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x5b7a4a, roughness: 0.85 });
  const potMat = new THREE.MeshStandardMaterial({ color: 0x8a5a3a, roughness: 0.9 });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xd8b46a, roughness: 0.4, metalness: 0.4,
    emissive: 0x5a3c14, emissiveIntensity: 0.35,
  });

  const rows = [];
  for (let i = 0; i < libros.length; i += PER_ROW) rows.push(libros.slice(i, i + PER_ROW));

  const bookMeshes = [];
  let worldWidth = 4;

  function buildRow(rowBooks, rowIndex) {
    const y = -rowIndex * ROW_HEIGHT;
    const widths = rowBooks.map((l) => Math.max(0.32, Math.min(0.85, (l.espesor || 40) / 100)));
    const rowWidth = widths.reduce((a, b) => a + b + BOOK_GAP, -BOOK_GAP);
    worldWidth = Math.max(worldWidth, rowWidth);

    const plank = new THREE.Mesh(new THREE.BoxGeometry(rowWidth + 1.2, SHELF_THICK, SHELF_DEPTH), woodMat);
    plank.position.set(0, y - BOOK_HEIGHT / 2 - SHELF_THICK / 2, 0);
    worldGroup.add(plank);

    const back = new THREE.Mesh(new THREE.BoxGeometry(rowWidth + 1.4, ROW_HEIGHT, 0.15), woodDarkMat);
    back.position.set(0, y - ROW_HEIGHT / 2 + BOOK_HEIGHT / 2, -SHELF_DEPTH / 2);
    worldGroup.add(back);

    let cursor = -rowWidth / 2;
    rowBooks.forEach((libro, colIndex) => {
      const w = widths[colIndex];
      const h = BOOK_HEIGHT * (0.86 + ((hashCode(libro.id) % 10) / 10) * 0.28);
      const mesh = new THREE.Mesh(
        new THREE.BoxGeometry(w, h, BOOK_DEPTH),
        new THREE.MeshStandardMaterial({ color: new THREE.Color(libro.color || "#6b4226"), roughness: 0.75 })
      );
      const x = cursor + w / 2;
      mesh.position.set(x, y - BOOK_HEIGHT / 2 + h / 2, 0);
      mesh.userData.libro = libro;
      mesh.userData.baseZ = 0;
      mesh.userData.popped = false;
      worldGroup.add(mesh);
      bookMeshes.push(mesh);

      const pages = new THREE.Mesh(new THREE.BoxGeometry(w * 0.15, h * 0.86, BOOK_DEPTH * 0.9), pageMat);
      pages.position.set(x + w * 0.36, mesh.position.y, 0.02);
      worldGroup.add(pages);

      if (readIds && readIds.has(libro.id)) addBadge(mesh, x, mesh.position.y, w, h);

      cursor += w + BOOK_GAP;
    });
  }

  function addBadge(mesh, x, y, w, h) {
    if (mesh.userData.badge) return;
    const badge = new THREE.Mesh(new THREE.BoxGeometry(w * 0.5, 0.12, 0.12), goldMat);
    badge.position.set(x, y + h / 2 + 0.1, BOOK_DEPTH / 2 - 0.05);
    worldGroup.add(badge);
    mesh.userData.badge = badge;
  }

  rows.forEach(buildRow);

  const totalHeight = rows.length * ROW_HEIGHT + 1.6;

  [-1, 1].forEach((side) => {
    const pillar = new THREE.Mesh(new THREE.BoxGeometry(0.3, totalHeight, SHELF_DEPTH), woodDarkMat);
    pillar.position.set(side * (worldWidth / 2 + 0.9), -((rows.length - 1) * ROW_HEIGHT) / 2, 0);
    worldGroup.add(pillar);
  });

  const floor = new THREE.Mesh(new THREE.BoxGeometry(worldWidth + 4, 0.2, 3), woodMat);
  floor.position.set(0, -((rows.length - 1) * ROW_HEIGHT) - BOOK_HEIGHT / 2 - 0.5, 0.4);
  worldGroup.add(floor);

  // ---- A quiet corner: potted plant + small lamp ----
  const foliage = new THREE.Group();
  for (let i = 0; i < 6; i++) {
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.45 + Math.random() * 0.3, 0.16), leafMat);
    leaf.position.set((Math.random() - 0.5) * 0.4, 0.55 + Math.random() * 0.3, (Math.random() - 0.5) * 0.4);
    leaf.rotation.z = (Math.random() - 0.5) * 0.4;
    foliage.add(leaf);
  }
  const plantGroup = new THREE.Group();
  const pot = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.5), potMat);
  pot.position.y = 0.2;
  plantGroup.add(pot, foliage);
  plantGroup.position.set(-(worldWidth / 2 + 0.55), 0.35, 0.55);
  worldGroup.add(plantGroup);

  const lampGroup = new THREE.Group();
  const lampPole = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.9, 0.12), woodDarkMat);
  lampPole.position.y = 0.45;
  const lampShadeMat = new THREE.MeshStandardMaterial({ color: 0xffdfa0, emissive: 0xffb066, emissiveIntensity: 0.6, roughness: 0.6 });
  const lampShade = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.3, 0.5), lampShadeMat);
  lampShade.position.y = 0.95;
  lampGroup.add(lampPole, lampShade);
  lampGroup.position.set(worldWidth / 2 + 0.55, 0.3, 0.55);
  worldGroup.add(lampGroup);
  lampLight.position.set(lampGroup.position.x, 1.15, 0.7);

  // ---- Ambient dust particles ----
  const dustTexture = makeSoftDotTexture("rgba(255,225,170,0.95)");
  const dustCount = 55;
  const dustGeo = new THREE.BufferGeometry();
  const dustPos = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * (worldWidth + 4);
    dustPos[i * 3 + 1] = -Math.random() * totalHeight + 1;
    dustPos[i * 3 + 2] = (Math.random() - 0.5) * 2 + 0.8;
  }
  dustGeo.setAttribute("position", new THREE.BufferAttribute(dustPos, 3));
  const dustPoints = new THREE.Points(
    dustGeo,
    new THREE.PointsMaterial({ size: 0.06, map: dustTexture, transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending })
  );
  worldGroup.add(dustPoints);

  // ---- Fixed-angle camera pan (X/Y only) with easing + inertia ----
  const targetPan = { x: 0, y: 0 };
  const bounds = { minX: 0, maxX: 0, minY: -((rows.length - 1) * ROW_HEIGHT), maxY: 0 };
  let dragging = false;
  let last = { x: 0, y: 0 };
  let downInfo = { x: 0, y: 0, t: 0 };

  function recomputeBounds() {
    const dist = camera.position.z;
    const vFov = (camera.fov * Math.PI) / 180;
    const visH = 2 * Math.tan(vFov / 2) * dist;
    const visW = visH * camera.aspect;
    bounds.maxX = Math.max(0, (worldWidth - visW * 0.7) / 2);
    bounds.minX = -bounds.maxX;
  }
  function clampPan() {
    targetPan.x = Math.max(bounds.minX, Math.min(bounds.maxX, targetPan.x));
    targetPan.y = Math.max(bounds.minY, Math.min(bounds.maxY, targetPan.y));
  }

  const raycaster = new THREE.Raycaster();
  const ndc = new THREE.Vector2();

  function onPointerDown(e) {
    dragging = true;
    last = { x: e.clientX, y: e.clientY };
    downInfo = { x: e.clientX, y: e.clientY, t: performance.now() };
  }
  function onPointerMove(e) {
    if (!dragging) return;
    const dx = e.clientX - last.x;
    const dy = e.clientY - last.y;
    const scale = 0.006;
    targetPan.x -= dx * scale;
    targetPan.y += dy * scale;
    clampPan();
    last = { x: e.clientX, y: e.clientY };
  }
  function onPointerUp(e) {
    if (!dragging) return;
    dragging = false;
    const dist = Math.hypot(e.clientX - downInfo.x, e.clientY - downInfo.y);
    const dt = performance.now() - downInfo.t;
    if (dist < 8 && dt < 350) handleTap(e.clientX, e.clientY);
  }
  function handleTap(px, py) {
    const rect = container.getBoundingClientRect();
    ndc.x = ((px - rect.left) / rect.width) * 2 - 1;
    ndc.y = -((py - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(ndc, camera);
    const hits = raycaster.intersectObjects(bookMeshes, false);
    if (hits.length) selectBook(hits[0].object);
  }

  container.addEventListener("pointerdown", onPointerDown);
  window.addEventListener("pointermove", onPointerMove);
  window.addEventListener("pointerup", onPointerUp);
  window.addEventListener("pointercancel", () => (dragging = false));

  function selectBook(mesh) {
    if (mesh.userData.popped) return;
    mesh.userData.popped = true;
    const start = performance.now();
    function pop() {
      const t = Math.min(1, (performance.now() - start) / 260);
      const ease = 1 - Math.pow(1 - t, 3);
      mesh.position.z = mesh.userData.baseZ + ease * 0.9;
      mesh.rotation.y = ease * 0.15;
      if (t < 1) requestAnimationFrame(pop);
      else {
        if (onSelectBook) onSelectBook(mesh.userData.libro);
        window.setTimeout(() => resetBook(mesh), 1700);
      }
    }
    requestAnimationFrame(pop);
  }
  function resetBook(mesh) {
    const start = performance.now();
    const fromZ = mesh.position.z;
    const fromRotY = mesh.rotation.y;
    function back() {
      const t = Math.min(1, (performance.now() - start) / 260);
      mesh.position.z = fromZ * (1 - t) + mesh.userData.baseZ * t;
      mesh.rotation.y = fromRotY * (1 - t);
      if (t < 1) requestAnimationFrame(back);
      else mesh.userData.popped = false;
    }
    requestAnimationFrame(back);
  }

  // ---- Render loop ----
  const clock = new THREE.Clock();
  function tick() {
    const dt = Math.min(clock.getDelta(), 0.05);
    const t = clock.elapsedTime;

    camera.position.x += (targetPan.x - camera.position.x) * 0.09;
    camera.position.y += (targetPan.y - camera.position.y) * 0.09;
    camera.lookAt(camera.position.x, camera.position.y, 0);

    foliage.rotation.z = Math.sin(t * 0.6) * 0.05;
    lampShadeMat.emissiveIntensity = 0.55 + Math.sin(t * 2.3) * 0.05;
    lampLight.intensity = 0.9 + Math.sin(t * 2.3) * 0.08;

    const pos = dustGeo.attributes.position.array;
    for (let i = 0; i < dustCount; i++) {
      pos[i * 3 + 1] += dt * 0.06;
      if (pos[i * 3 + 1] > 1.5) pos[i * 3 + 1] = -totalHeight + 0.5;
      pos[i * 3] += Math.sin(t * 0.3 + i) * 0.0006;
    }
    dustGeo.attributes.position.needsUpdate = true;

    renderer.render(scene, camera);
    requestAnimationFrame(tick);
  }

  function handleResize() {
    const w = container.clientWidth, h = container.clientHeight;
    if (!w || !h) return;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    recomputeBounds();
    clampPan();
  }
  window.addEventListener("resize", handleResize);

  recomputeBounds();
  handleResize();
  requestAnimationFrame(tick);

  function addSecretRow(libro) {
    const rowIndex = rows.length;
    buildRow([libro], rowIndex);
    rows.push([libro]);
    bounds.minY = -((rows.length - 1) * ROW_HEIGHT);
    clampPan();
  }

  return {
    setReadIds(newReadIds) {
      bookMeshes.forEach((mesh) => {
        const libro = mesh.userData.libro;
        if (newReadIds.has(libro.id) && !mesh.userData.badge) {
          const h = mesh.geometry.parameters.height;
          const w = mesh.geometry.parameters.width;
          addBadge(mesh, mesh.position.x, mesh.position.y, w, h);
        }
      });
    },
    addSecretBook(libro) {
      addSecretRow(libro);
    },
  };
}
